﻿function addolt() {
    document.write("<div class='container-fluid mt-100'>" +
        "<div class='row'>" +
        " <div class='col-md-12'>" +
        "<div class='card mb-4'>" +
        " <div class='card-header'>" +
        "<div class='media flex-wrap w-100 align-items-center'> <img src='https://i.imgur.com/iNmBizf.jpg' class='d-block ui-w-40 rounded-circle' alt=''> " +
        "  <div class='media-body mr-3 text-right pl-3' > <a href='javascript:void(0)' data-abc='true'> عنوان </a>" +
        "  <div class='text-muted small'>عدد الايام</div>" +
        " </div>" +
        " <div class='text-muted small mr-3'>" +
        "  <div>عضو منذ: <strong>01/1/2019</strong></div>" +
        "   <div><strong>134</strong> المشاركات</div>" +
        "  </div>" +
        "</div>" +
        " </div>" +
        " <div class='card-body text-right'>" +
        " <p> مجرد نص " +
        " </p>" +
        " </div>" +
        " <div class='card-footer d-flex flex-wrap justify-content-between align-items-center px-0 pt-0 pb-3'>" +
        " <div class='px-4 pt-3'> <a href='javascript:void(0)' class='text-muted d-inline-flex align-items-center align-middle' data-abc='true'> <i class='fa fa-heart text-danger'></i>&nbsp; عدد الردود: <span class='align-middle'>445</span> </a> " +
        "   <span class='text-muted d-inline-flex align-items-center align-middle ml-4'> <i class='fa fa-eye text-muted fsize-3'></i>&nbsp; عدد الزيارات :<span class='align-middle'>14532</span> </span> </div>" +
        "  <div class='px-4 pt-3'> <button onclick='javascript:alert(ElementalID)'; type='button' class='btn btn-primary'><i class='ion ion-md-create'></i>&nbsp; رد</button> </div>" +
        " </div>" +
        " </div>" +
        " </div>" +
        " </div>" +
        "</div>");
}